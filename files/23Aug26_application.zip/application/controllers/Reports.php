<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Dompdf\Dompdf;
use Dompdf\Options;
class Reports extends MY_Controller {
	public function __construct(){
		parent::__construct();
		$this->load_global();
		$this->load->model('reports_model','reports');
	}

	public function void_logs(){
		$this->permission_check('sales_report');
		$data=$this->data;
		$data['page_title']='Void Logs Report';
		$data['logs']=$this->db
			->select('v.*, s.salesman_name, u.username, COUNT(i.id) AS item_count')
			->from('db_voidlogs v')
			->join('db_voidlogitems i','i.void_log_id=v.id','left')
			->join('db_salesman s','s.id=v.salesman_id','left')
			->join('db_users u','u.id=v.user_id','left')
			->where('v.store_id',get_current_store_id())
			->group_by('v.id')->order_by('v.id','DESC')->get()->result();
		$this->load->view('report-void-logs',$data);
	}

	public function void_log_items($id){
		$this->permission_check('sales_report');
		$data=$this->data;
		$data['page_title']='Void Log Items';
		$data['log']=$this->db
			->select('v.*, s.salesman_name, u.username')
			->from('db_voidlogs v')
			->join('db_salesman s','s.id=v.salesman_id','left')
			->join('db_users u','u.id=v.user_id','left')
			->where('v.id',(int)$id)->where('v.store_id',get_current_store_id())->get()->row();
		if(!$data['log']) show_404();
		$data['items']=$this->db->where('void_log_id',(int)$id)->order_by('id','ASC')->get('db_voidlogitems')->result();
		$this->load->view('report-void-log-items',$data);
	}
	
	
	//Supplier Items Report 
	public function supplier_items(){
		$this->permission_check('supplier_items_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('supplier_items_report');
		$this->load->view('report-supplier_items', $data);
	}
	public function show_supplier_items_report(){
		echo $this->reports->show_supplier_items_report();
	}
	
	//Sales Report 
	public function sales(){
		$this->permission_check('sales_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('sales_report');
		$this->load->view('report-sales', $data);
	}
	public function show_sales_report(){
		echo $this->reports->show_sales_report();
	}

	//Sales Return Report 
	public function sales_return(){
		$this->permission_check('sales_return_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('sales_return_report');
		$this->load->view('report-sales-return', $data);
	}
	public function show_sales_return_report(){
		echo $this->reports->show_sales_return_report();
	}

	//Purchase report
	public function purchase(){
		$this->permission_check('purchase_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('purchase_report');
		$this->load->view('report-purchase', $data);
	}
	public function show_purchase_report(){
		echo $this->reports->show_purchase_report();
	}

	//Purchase Return report
	public function purchase_return(){
		$this->permission_check('purchase_return_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('purchase_return_report');
		$this->load->view('report-purchase-return', $data);
	}
	public function show_purchase_return_report(){
		echo $this->reports->show_purchase_return_report();
	}

	//Expense report
	public function expense(){
		$this->permission_check('expense_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('expense_report');
		$this->load->view('report-expense', $data);
	}
	public function show_expense_report(){
		echo $this->reports->show_expense_report();
	}
	//Profit report
	public function profit_loss(){
		$this->permission_check('profit_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('profit_and_loss_report');
		$this->load->view('report-profit-loss', $data);
	}
	public function get_profit_by_item(){
		echo $this->reports->get_profit_by_item();
	}
	public function get_profit_by_invoice(){
		echo $this->reports->get_profit_by_invoice();
	}

	//Summary report
	public function stock(){
		$this->permission_check('stock_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('stock_report');
		$this->load->view('report-stock', $data);
	}
	/*Stock Report*/
	public function show_stock_report(){
		return $this->reports->show_stock_report();
	}
	public function brand_wise_stock(){
		return $this->reports->brand_wise_stock();
	}
	public function get_stock_report(){
		$data = array(
			'item_wise_report' => $this->show_stock_report(),
			'brand_wise_stock' => $this->brand_wise_stock(),
			//'category_wise_stock' => $this->category_wise_stock(),
		);
		//print_r($data);exit;
		echo json_encode($data); 
	}

	//Item Sales Report 
	public function item_sales(){
		$this->permission_check('item_sales_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('item_sales_report');
		$this->load->view('report-sales-item', $data);
	}
	public function show_item_sales_report(){
		echo $this->reports->show_item_sales_report();
	}
	//Return Item Report 
	public function return_item(){
		$this->permission_check('return_items_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('return_items_report');
		$this->load->view('report-return-item', $data);
	}
	public function show_return_items_report(){
		echo $this->reports->show_return_items_report();
	}
	
	//Purchase Payments report
	public function purchase_payments(){
		$this->permission_check('purchase_payments_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('purchase_payments_report');
		$this->load->view('report-purchase-payments', $data);
	}
	public function show_purchase_payments_report(){
		echo $this->reports->show_purchase_payments_report();
	}

	//Sales Payments report
	public function sales_payments(){
		$this->permission_check('sales_payments_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('sales_payments_report');
		$this->load->view('report-sales-payments', $data);
	}
	public function show_sales_payments_report(){
		echo $this->reports->show_sales_payments_report();
	}
	//Expired Items Report 
	public function expired_items(){
		$this->permission_check('expired_items_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('expired_items_report');
		$this->load->view('report-expired-items', $data);
	}
	public function show_expired_items_report(){
		echo $this->reports->show_expired_items_report();
	}
	public function get_profit_loss_report(){
		echo json_encode($this->reports->get_profit_loss_report());
	}


	//Item Sales Report 
	public function seller_points(){
		$this->permission_check('seller_points_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('seller_points_report');
		$this->load->view('report-seller-points', $data);
	}
	public function show_seller_points_report(){
		echo $this->reports->show_seller_points_report();
	}
	
	//Sales Tax Report 
	public function sales_tax(){
		$this->permission_check('sales_tax_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('sales_tax_report');
		$this->load->view('report-sales-tax', $data);
	}
	public function show_sales_tax_report(){
		echo $this->reports->show_sales_tax_report();
	}

	//purchase Tax Report 
	public function purchase_tax(){
		$this->permission_check('purchase_tax_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('purchase_tax_report');
		$this->load->view('report-purchase-tax', $data);
	}
	public function show_purchase_tax_report(){
		echo $this->reports->show_purchase_tax_report();
	}

	//GSTR-1 Report 
	public function gstr_1(){
		$this->permission_check('gstr_1_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('gstr_1_report');
		$this->load->view('gst/report-gstr-1', $data);
	}
	public function show_gstr_1_report(){
		echo $this->reports->show_gstr_1_report();
	}
	//GSTR-2 Report 
	public function gstr_2(){
		$this->permission_check('gstr_2_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('gstr_2_report');
		$this->load->view('gst/report-gstr-2', $data);
	}
	public function show_gstr_2_report(){
		echo $this->reports->show_gstr_2_report();
	}

	//Customer Sales Item GST Report 
	public function sales_gst_report(){
		$this->permission_check('sales_gst_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('sales_gst_report');
		$this->load->view('gst/report-sales-gst', $data);
	}
	public function show_sales_gst_report(){
		echo $this->reports->show_sales_gst_report();
	}
	//Purchase Item GST Report 
	public function purchase_gst_report(){
		$this->permission_check('purchase_gst_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('purchase_gst_report');
		$this->load->view('gst/report-purchase-gst', $data);
	}
	public function show_purchase_gst_report(){
		echo $this->reports->show_purchase_gst_report();
	}
	
	//Sales Report 
	public function customer_orders(){
		$this->permission_check('customer_orders_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('customer_orders');
		$this->load->view('report-customer-orders', $data);
	}
	public function show_customer_orders(){
		echo $this->reports->show_customer_orders();
	}

	//Delivery sheet report
	public function delivery_sheet(){
		$this->permission_check('delivery_sheet_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('delivery_sheet_report');
		$this->load->view('report-delivery-sheet', $data);
	}
	public function show_delivery_sheet(){
		echo $this->reports->show_delivery_sheet();
	}

	//Load sheet report
	public function load_sheet(){
		$this->permission_check('load_sheet_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('load_sheet_report');
		$this->load->view('report-load-sheet', $data);
	}
	public function show_load_sheet(){
		echo $this->reports->show_load_sheet();
	}
	
	//Sales & payments records 
	public function sales_and_payments(){
		$this->permission_check('sales_report');
		$data=$this->data;
		$data['page_title']=$this->lang->line('sales_and_payments_report');
		$this->load->view('report-sales-and-payments', $data);
	}
	public function sales_and_payments_report(){
		echo $this->reports->sales_and_payments_report();
	}

public function customer_statements()
  {
  //$this->permission_check('customer_statement');
  $data = $this->data;
  $data['page_title'] = 'Customer Statement';
  //var_dump($_GET['from_date']); exit();
  if(isset($_GET['customer_id']))
    {
    $sdate = date("Y-m-d", strtotime($_GET['from_date']));
    $edate = date("Y-m-d", strtotime($_GET['to_date']));
    $custid = $_GET['customer_id'];
    //var_dump($sdate);var_dump($edate);var_dump($custid); exit();
    $data['sdate'] = $sdate;
    $data['edate'] = $edate;
	$data['psdate'] = $_GET['from_date'];
	$data['pedate'] = $_GET['to_date'];
	$data['custid'] = $custid;

    $data['company'] = $this->reports->company_details();
    $data['customer'] = $this->reports->sales_cust_data($custid);
    
    $data['sale'] = $this->reports->sales_dcust_ledger_data($custid,$sdate,$edate);
    $data['payment'] = $this->reports->spayment_dcust_ledger_data($custid,$sdate,$edate);
    $data['voucher'] = $this->reports->voucher_dcust_ledger_data($custid,$sdate,$edate);
  	}
  //var_dump($data['sale']); exit();
  $this->load->view('customer_statement',$data);
}

public function supplier_statements()
  {
  //$this->permission_check('customer_statement');
  $data = $this->data;
  $data['page_title'] = 'Supplier Statement';
  //var_dump($_GET['from_date']); exit();
  if(isset($_GET['supid']))
    {
    $sdate = date("Y-m-d", strtotime($_GET['from_date']));
    $edate = date("Y-m-d", strtotime($_GET['to_date']));
    $supid = $_GET['supid'];
    //var_dump($sdate);var_dump($edate);var_dump($custid); exit();
    $data['sdate'] = $sdate;
    $data['edate'] = $edate;
    $data['psdate'] = $_GET['from_date'];
    $data['pedate'] = $_GET['to_date'];

    $data['company'] = $this->reports->company_details();
    $data['supplier'] = $this->reports->purchases_supplier_data($supid);
    
    $data['purchase'] = $this->reports->purchase_supplier_ledger_data($supid,$sdate,$edate);
    $data['payment'] = $this->reports->ppayment_supplier_ledger_data($supid,$sdate,$edate);
    $data['voucher'] = $this->reports->voucher_supplier_ledger_data($supid,$sdate,$edate);
  	}
  //var_dump($data['sale']); exit();
  $this->load->view('supplier_statements',$data);
}
	public function pdf_customer_statement()
	{
		if ($this->input->is_ajax_request())
		{
			$customer_id = $_POST['selectedCustomer'];
			$sfdate = $_POST['selectedStartDate'];
			$efdate = $_POST['selectedEndDate'];
			//die(print($customer_id));
		//die(print_r(json_encode($_POST))) ;
		//exit;
		}
		//die(print_r($_POST));
		//define('UPLOAD_DIR', './uploads/reports/');
		$data = $this->data;
		$data['page_title'] = 'Customer Statement';
		//var_dump($_GET['from_date']); exit();
		if (isset($customer_id)) {
			$sdate = date("Y-m-d", strtotime($sfdate));
			$edate = date("Y-m-d", strtotime($efdate));
			$custid = $customer_id;
			//var_dump($sdate);var_dump($edate);var_dump($custid); exit();
			$data['sdate'] = $sdate;
			$data['edate'] = $edate;
			$data['psdate'] = $sfdate;
			$data['pedate'] = $efdate;
			$data['custid'] = $custid;

			$data['company'] = $this->reports->company_details();
			$data['customer'] = $this->reports->sales_cust_data($custid);

			$data['sale'] = $this->reports->sales_dcust_ledger_data($custid, $sdate, $edate);
			$data['payment'] = $this->reports->spayment_dcust_ledger_data($custid, $sdate, $edate);
			$data['voucher'] = $this->reports->voucher_dcust_ledger_data($custid, $sdate, $edate);
		}
		//var_dump($data['sale']); exit();
		$this->load->view('customer_statement_pdf', $data);



		// Get output html
		$html = $this->output->get_output();
		$options = new Options();
		$options->set('isRemoteEnabled', true);
		$dompdf = new Dompdf($options);

		// Load HTML content
		$dompdf->loadHtml($html, 'UTF-8');

		// (Optional) Setup the paper size and orientation
		$dompdf->setPaper('A4', 'portrait');/*landscape or portrait*/

		// Render the HTML as PDF
			$dompdf->render();
			$pdf = $dompdf->output();
			define('UPLOAD_DIR', './uploads/reports/');
			$repName = 'customer_statement';
			@file_put_contents(UPLOAD_DIR . $repName . ".pdf", $pdf);
			$upload_path = 'uploads/reports/';
			// echo json_encode(base_url() . $upload_path . "customer_statement.pdf");
			$data['report_url'] = base_url() . $upload_path . "customer_statement.pdf";
			die(json_encode($data));
	}
	// public function pdf_customer_statement_v1
	// ()
	// {
	// 	define('UPLOAD_DIR', './uploads/reports/');
	// 	//die(print("nazmul"));
	// 	if (!empty($_POST['pdf'])) {
	// 		$html = urldecode($_POST['pdf']);
	// 		@file_put_contents("texto.html", $html);
	// 		$name = str_replace(" ", "+", $_POST['repName']);
	// 		$nombre = $name;

	// 		# Instanciamos un objeto de la clase DOMPDF.
	// 		$options = new Options();
	// 		$options->setIsRemoteEnabled(true);

	// 		$mipdf =  new Dompdf($options);

	// 		# Definimos el tamaño y orientación del papel que queremos.
	// 		# O por defecto cogerá el que está en el fichero de configuración.
	// 		$mipdf->setPaper("A4", "portrait");

	// 		# Cargamos el contenido HTML.
	// 		$mipdf->loadHtml($html);

	// 		# Renderizamos el documento PDF.
	// 		$mipdf->render();

	// 		# Enviamos el fichero PDF al navegador.
	// 		//$mipdf ->stream("Claustro.pdf");
	// 		$pdf = $mipdf->output();
	// 		@file_put_contents(UPLOAD_DIR . $nombre . ".pdf", $pdf);
	// 		$upload_path = 'uploads/reports/';
	// 		echo json_encode(base_url() . $upload_path . $nombre . ".pdf");
	// 		//}
	// 	}
	// }

	public function pdf_customer_statement_test()
	{
		
		// $data['report_url'] = base_url() . $upload_path . "customer_statement.pdf";
		$data['report_url'] = "test";
		echo json_encode($data);
	}
}

